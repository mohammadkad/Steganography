
/*
const httpServer = require("http").createServer();
const io = require("socket.io")(httpServer, {
  cors: {
    origin: "http://localhost:8080",
  },
});
*/
var siofu = require("socketio-file-upload");
const fs = require('fs');


// ---
const express = require('express');
const app = express().use(siofu.router);
const http = require('http').createServer(app); // Create server using Express
const io = require('socket.io')(http, {
  cors: {
    origin: "http://localhost:8080",
  },
});
// ---

io.use((socket, next) => {
  const username = socket.handshake.auth.username;
  if (!username) {
    return next(new Error("invalid username"));
  }
  socket.username = username;
  next();
});

io.on("connection", (socket) => {
  // fetch existing users
  const users = [];
  for (let [id, socket] of io.of("/").sockets) {
    users.push({
      userID: id,
      username: socket.username,
    });
  }
  socket.emit("users", users);

  // notify existing users
  socket.broadcast.emit("user connected", {
    userID: socket.id,
    username: socket.username,
  });

  // forward the private message to the right recipient
  socket.on("private message", ({ content, to }) => {
    socket.to(to).emit("private message", {
      content,
      from: socket.id,
    });
	console.log(content + "._."); // Test By MK ;)
	
	//---
	fs.writeFile("1.jpg", content, (err) => {
      console.log("Error");
    });
	//---
	
  });

  // notify users upon disconnection
  socket.on("disconnect", () => {
    socket.broadcast.emit("user disconnected", socket.id);
  });
  
  /*
  socket.on("upload", () => {
    console.log("...");
	//console.log(file);
  });
  */
  
  socket.on("upload", (file, callback) => {
	console.log("File received.");  
    // console.log(file); // <Buffer 25 50 44 ...>

    // save the content to the disk, for example
	/*
    writeFile("/tmp/upload", file, (err) => {
      callback({ message: err ? "failure" : "success" });
    });
	*/
  });
  
  
});


/*
const PORT = process.env.PORT || 3000;

httpServer.listen(PORT, () =>
  console.log(`server listening at http://localhost:${PORT}`)
);

*/

// OK- WORK WELL
// -----------------------------
http.listen(3000, () => {
  console.log('Server listening on port 3000');
});
// -----------------------------

